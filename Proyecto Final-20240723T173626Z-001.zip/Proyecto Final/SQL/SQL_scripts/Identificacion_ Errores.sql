use logista;
#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
##
## A) Se tarda como mínimo un día desde que la fruta se recoge hasta que llega al cliente.
##
#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
SELECT MAX(TIMESTAMPDIFF(HOUR, f_recogida, f_venta)) AS Transito_máx_Horas
FROM logista.ventas v
LEFT JOIN logista.compras c ON v.producto_id=c.producto_id;

##El tiempo de tránsito máximo es de 20 horas por lo que, posiblemente, la condición del enunciado sea errónea.

#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
##
## B) A cada proveedor no se le pueden comprar en un mismo día más de 100 kg de una mism fruta.
##               (Asumimos la fecha de recogida como fecha de compra)
#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
with diario_fruta_proveedor AS (
		SELECT DATE(f_recogida), proveedor_id, tipo_id, ROUND(SUM(peso)/1000, 2) AS kg_diario_fruta_proveedor
		FROM logista.ventas v
		LEFT JOIN logista.compras  c ON v.producto_id=c.producto_id
		GROUP BY DATE(f_recogida), proveedor_id, tipo_id
		ORDER BY DATE(f_recogida), proveedor_id)
SELECT MAX(kg_diario_fruta_proveedor) AS Max_kg_diario_fruta_proveedor
FROM diario_fruta_proveedor;

#Las cantidades reales son muy inferiores al límite máximo impuesto por la condición, por lo que no se incumple.

#CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
##
## C) No hay marcas que produzcan mas de un tipo de fruta
##                 
#CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
WITH Tipos_por_marca AS (
	SELECT marca_id AS Marca, COUNT(DISTINCT tipo_id) AS Tipos_por_marca
	FROM producto p
	LEFT JOIN compras c ON p.id_producto=c.producto_id
	GROUP BY marca_id)
SELECT MIN(Tipos_por_marca) AS Minimo_tipos_por_marca
FROM Tipos_por_marca;

#Cada marca produce, por lo menos, 15 tipos. La condición no se cumple en ningún caso

#DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
## 
## D) Un mismo lote no puede contener marcas o frutas distintas
##                 
#DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

WITH marca_fruta_por_lote AS(
	SELECT codigo_lote AS Lote, COUNT(DISTINCT id_producto) AS Frutas_por_lote, COUNT(DISTINCT tipo_id) AS Tipos_por_lote
	FROM producto p
	LEFT JOIN compras c ON p.id_producto=c.producto_id
	GROUP BY Lote)
SELECT MAX(Frutas_por_lote),  MAX(Tipos_por_lote)
FROM marca_fruta_por_lote;

#No hay lotes con mas de un tipo de fruta, aunque sí hay lotes con mas de una fruta del mismo tipo.