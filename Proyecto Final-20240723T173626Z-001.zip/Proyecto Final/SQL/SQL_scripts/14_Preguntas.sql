#Seleccionar Base de Datos
USE logista;

#111111111111111111111111111111111111111
#(1) Calcular la media diaria de la cuantía de distribuciones
#111111111111111111111111111111111111111
with medias_diarias AS(
	SELECT DATE(f_venta) AS fecha,
		   SUM(precio_venta) AS venta_diaria
	FROM logista.ventas
	WHERE DATE(f_venta) BETWEEN '2022-09-01' AND '2022-09-30'
    GROUP BY DATE(f_venta))
SELECT ROUND(AVG(venta_diaria), 2) AS promedio_ventas_dia
FROM medias_diarias;


#222222222222222222222222222222222222222
#(2) Calcular la cuantía total de las distribuciones
#222222222222222222222222222222222222222
SELECT ROUND(SUM(precio_venta), 2) as total_distribuciones
FROM logista.ventas
WHERE DATE(f_venta) BETWEEN '2022-09-01' AND '2022-09-30';

#333333333333333333333333333333333333333
#(3) ¿Qué dias del mes se han producido más distribuciones y cuantas?
#333333333333333333333333333333333333333
SELECT DATE(f_venta) AS fecha, 
	COUNT(producto_id) AS distribuciones_diarias
FROM ventas
WHERE DATE(f_venta) between '20220901' and '20220930'
GROUP BY fecha
ORDER BY distribuciones_diarias DESC
LIMIT 10;

#444444444444444444444444444444444444444
#(4) ¿A qué horas del día se producen más recogidas de alimentos y cuantas? (cuantos productos ó 't_id')
#444444444444444444444444444444444444444
# Por producto:
SELECT HOUR(f_recogida) as hora,
		COUNT(*) as recogida_productos_hora
FROM compras
GROUP BY hora
ORDER BY recogida_productos_hora DESC
LIMIT 10;
# Por peso:
SELECT HOUR(f_recogida) as hora,
		ROUND(sum(peso)/1000, 3) as kg_recogidos_hora
FROM compras
GROUP BY hora
ORDER BY kg_recogidos_hora DESC
LIMIT 10;

#555555555555555555555555555555555555555
#(5) ¿Cuales son los cinco clientes que mas dinero han gastasdo comprando la fruta y cuanto?
#555555555555555555555555555555555555555
SELECT cliente, ROUND(SUM(precio_venta), 0) AS Compras_cliente
FROM logista.ventas v
LEFT JOIN logista.cliente c ON v.cliente_id=c.id_cliente
GROUP BY cliente
ORDER BY Compras_cliente DESC
LIMIT 5;

#666666666666666666666666666666666666666
#(6) ¿Cuales son los cinco clientes que menos dinero han gastasdo comprando la fruta y cuanto?
#666666666666666666666666666666666666666
SELECT cliente, ROUND(SUM(precio_venta), 0) AS Compras_cliente
FROM logista.ventas v
LEFT JOIN logista.cliente c ON v.cliente_id=c.id_cliente
WHERE DATE(f_venta) between '20220901' and '20220930'
GROUP BY cliente
ORDER BY Compras_cliente
LIMIT 5;

#777777777777777777777777777777777777777
#(7) ¿Cuales son los 10 proveedores que han recibido mas dinero y cuanto?
#777777777777777777777777777777777777777
SELECT proveedor AS Proveedor, ROUND(SUM(coste_inicial), 0) as Compras_a_proveedor
FROM logista.compras c
LEFT JOIN logista.proveedor p ON c.proveedor_id=p.id_proveedor
WHERE DATE(f_recogida) between '20220901' and '20220930'
GROUP BY proveedor
ORDER BY Compras_a_proveedor DESC
LIMIT 10;

#88888888888888888888888888888888888888
#(8) ¿Cuales son los 3 productos con mayor beneficio a lo largo del mes (los que al restarle 
#     al coste de venta el precio de compra se quedan con un mejor resultado y cual ha sido su balance?
#88888888888888888888888888888888888888
SELECT tipo AS Producto,
	ROUND(SUM(precio_venta)-SUM(coste_inicial), 0) as Beneficio_mensual
FROM compras c
LEFT JOIN ventas v ON c.producto_id=v.producto_id
LEFT JOIN tipo t ON t.id_tipo=c.tipo_id
WHERE precio_venta != 0
	AND	(DATE(f_recogida) BETWEEN '20220901' AND '20220930') 
    AND (DATE(f_venta) BETWEEN '20220901' AND '20220930')
GROUP BY tipo_id
ORDER BY Beneficio_mensual DESC
LIMIT 3;

#99999999999999999999999999999999999999
#(9)  ¿Cuales son los 3 productos con peor beneficio a lo largo de todo el mes y cuales han sido?
#99999999999999999999999999999999999999
SELECT tipo AS Producto,
	ROUND(SUM(precio_venta)-SUM(coste_inicial), 0) as Beneficio_mensual
FROM compras c
LEFT JOIN ventas v ON c.producto_id=v.producto_id
LEFT JOIN tipo t ON t.id_tipo=c.tipo_id
WHERE precio_venta != 0
	AND	(DATE(f_recogida) BETWEEN '20220901' AND '20220930') 
    AND (DATE(f_venta) BETWEEN '20220901' AND '20220930')
GROUP BY tipo_id
ORDER BY Beneficio_mensual
LIMIT 3;

#10101010101010101010101010101010101010
#(10) ¿Cual es el precio de venta medio de cada fruta?
#10101010101010101010101010101010101010
SELECT tipo, ROUND(SUM(precio_venta)/SUM(peso)*1000, 2) AS Precio_medio_Kg
FROM ventas v
LEFT JOIN compras c ON c.producto_id=v.producto_id
left JOIN tipo t ON t.id_tipo=c.tipo_id
WHERE  precio_venta != 0
	AND (DATE(f_venta) BETWEEN '20220901' AND '20220930')
GROUP BY c.tipo_id;
#11111111111111111111111111111111111111
#(11) Suponiendo que si no se dispone de informació n de venta se trata de una fruta que no ha podido 
#     venderse por haber sido dañada durante la distribución ¿cuanta fruta de cada tipo ha sido dañada?
#11111111111111111111111111111111111111
SELECT tipo AS Producto_perdido, ROUND(SUM(peso)/1000, 1) AS Total_Kg, ROUND(SUM(coste_inicial), 2) AS Total_coste
FROM compras c
LEFT JOIN ventas v ON c.producto_id=v.producto_id
LEFT JOIN tipo t ON c.tipo_id=t.id_tipo
WHERE  v.precio_venta = 0
	AND (DATE(f_recogida) BETWEEN '20220901' AND '20220930')
GROUP BY tipo_id;

#12121212121212121212121212121212121212
#(12) ¿Cual ha sido la pérdida total de la fruta dañada?
#12121212121212121212121212121212121212
SELECT ROUND(SUM(peso)/1000, 1) AS Total_Kg_dañada, ROUND(SUM(coste_inicial), 4) AS Total_pérdida
FROM compras c
LEFT JOIN ventas v ON c.producto_id=v.producto_id
LEFT JOIN tipo t ON c.tipo_id=t.id_tipo
WHERE  v.precio_venta = 0
	AND (DATE(f_recogida) BETWEEN '20220901' AND '20220930');

#13131313131313131313131313131313131313
#(13) ¿Cual es la cuantía total de cada tipo fruta que han comprado los 5 clientes que más dinero han gastado?  -Similar a la (5)-
#13131313131313131313131313131313131313

WITH mejores_5_clientes AS (
	SELECT cliente_id
	FROM ventas v
	GROUP BY cliente_id
	ORDER BY SUM(precio_venta) DESC
	LIMIT 5)
SELECT tipo AS Tipo_fruta, SUM(precio_venta) AS Total_compras_5_clientes
FROM ventas v
LEFT JOIN compras co ON v.producto_id=co.producto_id
LEFT JOIN tipo t ON co.tipo_id=t.id_tipo
WHERE cliente_id IN (SELECT cliente_id FROM mejores_5_clientes)
GROUP BY tipo;

#14141414141414141414141414141414141414
#(14) Para cada producto calcular el porcentaje de beneficio (para cada tipo de fruta)
#14141414141414141414141414141414141414
SELECT tipo AS Producto, ROUND((SUM(precio_venta)-SUM(coste_inicial))/SUM(coste_inicial)*100, 2) AS 'Beneficio_%'
FROM ventas v
LEFT JOIN compras c ON v.producto_id=c.producto_id
LEFT JOIN tipo t ON c.tipo_id=t.id_tipo
GROUP BY c.tipo_id;