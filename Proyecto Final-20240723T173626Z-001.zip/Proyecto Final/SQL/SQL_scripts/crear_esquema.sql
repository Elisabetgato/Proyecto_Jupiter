# Crear un nuevo esquema
CREATE DATABASE IF NOT EXISTS logista;
USE logista;

#Eliminar las tablas si existen
DROP TABLE IF EXISTS Compras;
DROP TABLE IF EXISTS Ventas;
DROP TABLE IF EXISTS Producto;
DROP TABLE IF EXISTS Proveedor;
DROP TABLE IF EXISTS Cliente;
DROP TABLE IF EXISTS Marca;
DROP TABLE IF EXISTS Tipo;

#Crear la tabla Proveedor
CREATE TABLE IF NOT EXISTS Proveedor (
id_proveedor TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
proveedor	VARCHAR(38)
);

#Crear la tabla Cliente
CREATE TABLE IF NOT EXISTS Cliente (
id_cliente	TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
cliente	VARCHAR(28)
);

#Crear la tabla Marca
CREATE TABLE IF NOT EXISTS Marca (
id_marca	TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
marca	VARCHAR(21)
);

#Crear la tabla Tipo
CREATE TABLE IF NOT EXISTS tipo (
id_tipo	TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
tipo	VARCHAR(13)
);

#Crear la tabla Producto
CREATE TABLE IF NOT EXISTS Producto (
id_producto	INT AUTO_INCREMENT PRIMARY KEY,
marca_id 	 TINYINT UNSIGNED,
t_id	VARCHAR(38),
codigo_lote	VARCHAR(50),
FOREIGN KEY (marca_id) REFERENCES Marca(id_marca)
);

#Crear tabla Compras
CREATE TABLE IF NOT EXISTS Compras(
producto_id	 INT PRIMARY KEY,
tipo_id 	 TINYINT UNSIGNED,
peso	      DECIMAL(6, 2),
proveedor_id TINYINT UNSIGNED,
f_recogida	 DATETIME,
coste_inicial DECIMAL(6, 4),
FOREIGN KEY (producto_id) REFERENCES Producto(id_producto),
FOREIGN KEY (tipo_id) REFERENCES Tipo(id_tipo),
FOREIGN KEY (proveedor_id) REFERENCES Proveedor(id_proveedor)
);


#Crear tabla Ventas
CREATE TABLE IF NOT EXISTS Ventas(
producto_id	 INT PRIMARY KEY,
cliente_id 	 TINYINT UNSIGNED,
f_venta	      DATETIME,
precio_venta  DECIMAL(6, 4),
FOREIGN KEY (producto_id) REFERENCES Producto(id_producto),
FOREIGN KEY (cliente_id) REFERENCES Cliente(id_cliente)
);